import cv2
import subprocess
import time

def print_camera_info():
    """
    Print all available camera information using v4l2-ctl
    """
    print("\n=== Camera Formats ===")
    subprocess.run(['v4l2-ctl', '--list-formats-ext', '-d', '/dev/video0'])
    
    print("\n=== Camera Controls ===")
    subprocess.run(['v4l2-ctl', '--list-ctrls', '-d', '/dev/video0'])
    
    print("\n=== Current Settings ===")
    subprocess.run(['v4l2-ctl', '--get-fmt-video', '-d', '/dev/video0'])

def test_basic_capture():
    """
    Test basic camera capture without any special settings
    """
    print("\n=== Testing Basic Capture ===")
    cap = cv2.VideoCapture(0, cv2.CAP_V4L2)
    
    if not cap.isOpened():
        print("Failed to open camera")
        return
    
    # Print initial camera settings
    width = cap.get(cv2.CAP_PROP_FRAME_WIDTH)
    height = cap.get(cv2.CAP_PROP_FRAME_HEIGHT)
    print(f"Initial resolution: {width}x{height}")
    
    # Try to capture one frame
    print("Attempting to capture a frame...")
    ret, frame = cap.read()
    if ret:
        print("Successfully captured a frame!")
        print(f"Frame size: {frame.shape}")
    else:
        print("Failed to capture frame")
    
    cap.release()

def main():
    try:
        print("Getting camera information...")
        print_camera_info()
        
        print("\nTesting basic capture...")
        test_basic_capture()
        
    except Exception as e:
        print(f"Error: {str(e)}")

if __name__ == "__main__":
    main()
