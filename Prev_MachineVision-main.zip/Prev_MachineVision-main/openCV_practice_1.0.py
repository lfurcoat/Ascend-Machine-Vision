import cv2
import numpy as np
import time
import subprocess
import os

def set_v4l2_controls():
    """
    Set V4L2 controls using v4l2-ctl command line tool
    """
    try:
        # Set format to MJPG and resolution
        subprocess.run([
            'v4l2-ctl',
            '-d', '/dev/video0',
            '--set-fmt-video=width=1920,height=1080,pixelformat=RGB'
        ], check=True)
        
        # Additional controls that might help
        subprocess.run([
            'v4l2-ctl',
            '-d', '/dev/video0',
            '--set-ctrl=exposure_auto=1',  # Manual exposure
            '--set-ctrl=exposure_time_absolute=1000'  # Initial exposure time
        ], check=True)
        
        # Allow settings to take effect
        time.sleep(2)
        
    except subprocess.CalledProcessError as e:
        print(f"Error setting V4L2 controls: {str(e)}")
        raise

def setup_arducam():
    """
    Setup and initialize Arducam camera using OpenCV with V4L2 controls
    """
    # First set V4L2 controls
    set_v4l2_controls()
    
    # Open camera with V4L2 backend
    camera = cv2.VideoCapture(0, cv2.CAP_V4L2)
    
    if not camera.isOpened():
        raise RuntimeError("Failed to open camera. Check connections and permissions.")
    
    # Force resolution again through OpenCV
    camera.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc('R','G','B'))
    camera.set(cv2.CAP_PROP_FRAME_WIDTH, 1920)
    camera.set(cv2.CAP_PROP_FRAME_HEIGHT, 1080)
    camera.set(cv2.CAP_PROP_BUFFERSIZE, 1)  # Reduced buffer size
    
    # Allow camera to initialize
    time.sleep(2)
    
    return camera

def read_frame_with_timeout(camera, timeout=2.0):
    """
    Attempt to read a frame with a timeout
    """
    start_time = time.time()
    while (time.time() - start_time) < timeout:
        ret, frame = camera.read()
        if ret:
            return True, frame
        time.sleep(0.1)
    return False, None

def test_camera(camera):
    """
    Test camera by capturing and displaying frames with improved error handling
    """
    frame_count = 0
    start_time = time.time()
    consecutive_failures = 0
    
    while True:
        try:
            ret, frame = read_frame_with_timeout(camera)
            
            if not ret or frame is None:
                consecutive_failures += 1
                print(f"Frame capture failed, attempt {consecutive_failures}")
                if consecutive_failures >= 5:
                    print("Too many consecutive failures, exiting...")
                    break
                time.sleep(1)  # Added delay between retries
                continue
            
            consecutive_failures = 0
            frame_count += 1
            
            # Calculate actual FPS every 30 frames
            if frame_count % 30 == 0:
                elapsed_time = time.time() - start_time
                actual_fps = frame_count / elapsed_time
                print(f"Actual FPS: {actual_fps:.2f}")
            
            # Display the frame
            display_frame = cv2.resize(frame, (1280, 960))
            cv2.imshow('Arducam Test', display_frame)
            
            # Break loop on 'q' press
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
                
        except Exception as e:
            print(f"Error during capture: {str(e)}")
            break
    
    # Cleanup
    camera.release()
    cv2.destroyAllWindows()

def main():
    try:
        # Check if v4l2-ctl is available
        if os.system('which v4l2-ctl > /dev/null') != 0:
            print("v4l2-ctl not found. Installing...")
            os.system('sudo apt-get update && sudo apt-get install -y v4l-utils')
        
        print("Initializing camera...")
        camera = setup_arducam()
        
        # Get and print camera properties
        width = camera.get(cv2.CAP_PROP_FRAME_WIDTH)
        height = camera.get(cv2.CAP_PROP_FRAME_HEIGHT)
        fourcc = camera.get(cv2.CAP_PROP_FOURCC)
        
        print(f"Camera initialized with settings:")
        print(f"Resolution: {width}x{height}")
        print(f"Format: {chr(int(fourcc)&255)}{chr((int(fourcc)>>8)&255)}{chr((int(fourcc)>>16)&255)}{chr((int(fourcc)>>24)&255)}")
        
        print("Starting capture test...")
        test_camera(camera)
        
    except Exception as e:
        print(f"Error: {str(e)}")
        
    finally:
        cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
