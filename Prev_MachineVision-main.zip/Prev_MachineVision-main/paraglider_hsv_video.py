import cv2
import numpy as np

cap = cv2.VideoCapture("/home/masslab/Desktop/MachineVision/Paraglider_Video/ParagliderVideo/IMG.MOV")
#success, frame = cap.read()

def nothing(x):
    pass

cv2.namedWindow("Trackbars")

cv2.createTrackbar("L-H","Trackbars",0,255,nothing)
cv2.createTrackbar("L-S","Trackbars",0,255,nothing)
cv2.createTrackbar("L-V","Trackbars",0,255,nothing)
cv2.createTrackbar("U-H","Trackbars",0,255,nothing)
cv2.createTrackbar("U-S","Trackbars",0,255,nothing)
cv2.createTrackbar("U-V","Trackbars",0,255,nothing)

while True:
    success, frame = cap.read()
    
    frame = cv2.resize(frame, (640,480))

    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

    # l_h = cv2.getTrackbarPos("L-H","Trackbars")
    # l_s = cv2.getTrackbarPos("L-S","Trackbars")
    # l_v = cv2.getTrackbarPos("L-V","Trackbars")
    # u_h = cv2.getTrackbarPos("U-H","Trackbars")
    # u_s = cv2.getTrackbarPos("U-S","Trackbars")
    # u_v = cv2.getTrackbarPos("U-V","Trackbars")

    # lower = np.array([l_h,l_s,l_v])
    # upper = np.array([u_h,u_s,u_v])
    lower1 = np.array([12,124,93])
    upper1 = np.array([155,255,255])

    lower2 = np.array([23,179,0])
    upper2 = np.array([180,255,215])

    lower3 = np.array([0,126,93])
    upper3 = np.array([78,209,255])
    
    #mask1 = cv2.inRange(hsv, lower1, upper1)
    #mask2 = cv2.inRange(hsv, lower2, upper2)
    #mask3 = cv2.inRange(hsv, lower3, upper3)

    #combined_mask = mask1 + mask2 + mask3

    #result = cv2.bitwise_and(frame, frame, mask = combined_mask)
    ret, result = cv2.threshold(hsv,180,255,215,cv2.THRESH_BINARY)

    # ----
    # height = int(paraglider_video.get(cv.CAP_PROP_FRAME_HEIGHT))
    # width = int(paraglider_video.get(cv.CAP_PROP_FRAME_WIDTH))
    # fps = paraglider_video.get(cv.CAP_PROP_FPS)
    # total_frames = int(paraglider_video.get(cv.CAP_PROP_FRAME_COUNT))

    # fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    # output_video = cv2.VideoWriter('paraglider-hsv.mp4', fourcc, fps, (width, height))

    # while cap.isOpened():
    #     ret, result = cap.read()
    #     if not ret:
    #         break

    #     output_video.write(result)  # Write the frame
    #     cv2.imshow('Recording', result)  # Show the frame

    #     # Press 'q' to exit
    #     if cv2.waitKey(1) & 0xFF == ord('q'):
    #         break
    # ----

    cv2.imshow("Frame", frame)
    cv2.imshow("HSV", hsv)
    #cv2.imshow("Mask", combined_mask)
    cv2.imshow("Result", result)

    key = cv2.waitKey(1)
    if key == 27:
        break

    # output_video.release()
    
