import numpy as np
import cv2
import time
import os
from threading import Thread
from queue import Queue
from collections import deque
from statistics import mean

def gstreamer_pipeline(
    sensor_id=0,
    capture_width=1920,
    capture_height=1080,
    display_width=1920,
    display_height=1080,
    framerate=60,
    flip_method=0,
):
    return (
        "nvarguscamerasrc sensor-id=%d ! "
        "video/x-raw(memory:NVMM), width=(int)%d, height=(int)%d, framerate=(fraction)%d/1 ! "
        "nvvidconv flip-method=%d ! "
        "video/x-raw, width=(int)%d, height=(int)%d, format=(string)BGRx ! "
        "videoconvert ! "
        "video/x-raw, format=(string)BGR ! appsink max-buffers=1 drop=true"
        % (
            sensor_id,
            capture_width,
            capture_height,
            framerate,
            flip_method,
            display_width,
            display_height,
        )
    )

class FPSCounter:
    def __init__(self, window_size=30):
        self.timestamps = deque(maxlen=window_size)
        
    def update(self):
        self.timestamps.append(time.time())
        
    def get_fps(self):
        if len(self.timestamps) < 2:
            return 0
        intervals = [t2 - t1 for t1, t2 in zip(self.timestamps, list(self.timestamps)[1:])]
        return 1 / mean(intervals) if intervals else 0

class VideoWriter:
    def __init__(self, filename, fourcc, fps, frameSize):
        self.writer = cv2.VideoWriter(filename, fourcc, fps, frameSize)
        self.queue = Queue(maxsize=100)  # Reduced buffer size
        self.running = True
        self.thread = Thread(target=self._write_frames, daemon=True)
        self.thread.start()

    def write(self, frame):
        if not self.queue.full():
            self.queue.put(frame)  # No copying to avoid overhead
        else:
            print("Warning: Frame drop detected")

    def _write_frames(self):
        while self.running:
            if not self.queue.empty():
                frame = self.queue.get()
                self.writer.write(frame)
            else:
                time.sleep(0.001)  # Small sleep to prevent CPU thrashing

    def release(self):
        self.running = False
        print(f"Finalizing video: {self.queue.qsize()} frames remaining")
        # Simple drain without complex logic
        while not self.queue.empty():
            self.writer.write(self.queue.get())
        self.writer.release()
        print("Video finalized")

def main():
    # Constants
    KEY_R = ord('r')
    KEY_S = ord('s')
    KEY_Q = ord('q')
    KEY_ESC = 27
    VIDEO_FILE_SIZE = 100 * 1024 * 1024
    TARGET_FPS = 60
    
    # Initialize camera with minimalist pipeline
    pipeline = gstreamer_pipeline()
    cap = cv2.VideoCapture(pipeline, cv2.CAP_GSTREAMER)
    
    # Get camera properties
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    
    fps_counter = FPSCounter()
    
    print(f'VCAP width : {width}')
    print(f'VCAP height: {height}')
    
    # Try to set real-time scheduling priority
    try:
        os.nice(-10)  # Less extreme than -20
    except:
        print("Note: Could not set process priority")
    
    running = True
    recording = False
    video_writer = None
    window_name = time.strftime("%Y.%m.%d  %H.%M.%S", time.localtime())
    
    # Pre-calculate constants
    center_x = width // 2
    center_y = height // 2
    line_length = 25
    h_line_start = (center_x - line_length, center_y)
    h_line_end = (center_x + line_length, center_y)
    v_line_start = (center_x, center_y - line_length)
    v_line_end = (center_x, center_y + line_length)
    
    # Skip warmup frames directly
    for _ in range(10):
        cap.read()
    
    # Set window parameters
    cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)
    
    # Prepare video directory
    os.makedirs('./VideoTesting', exist_ok=True)
    
    while running:
        # Use read() directly for simplicity
        ret, frame = cap.read()
        if not ret:
            continue
            
        fps_counter.update()
        
        # Convert color space (minimized operations)
        gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        
        # Masking with optimized parameters
        mask1 = cv2.inRange(gray_frame, (0, 49, 0), (119, 255, 255))
        mask2 = cv2.inRange(gray_frame, (173, 25, 0), (180, 255, 155))
        mask_combined = mask1 + mask2  # Simpler operation
        
        # Apply mask
        result = cv2.bitwise_and(frame, frame, mask=mask_combined)
        
        # Draw crosshairs
        cv2.line(result, h_line_start, h_line_end, (255, 255, 255), 1)
        cv2.line(result, v_line_start, v_line_end, (255, 255, 255), 1)
        
        # Display FPS
        current_fps = fps_counter.get_fps()
        cv2.putText(result, f"FPS: {current_fps:.1f}", (10, 30), 
                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
        
        # Recording logic
        if recording:
            if video_writer is None:
                filename = f'./VideoTesting/{time.strftime("%Y.%m.%d_%H.%M.%S", time.localtime())}.avi'
                # Use MJPG codec for better performance
                fourcc = cv2.VideoWriter_fourcc(*'MJPG')
                video_writer = VideoWriter(filename, fourcc, TARGET_FPS, (width, height))
                print(f"Recording started: {filename}")
            
            # Write frame in threaded mode
            video_writer.write(result)
            
            # Only check file size periodically
            if cv2.getTickCount() % 60 == 0:
                if os.path.exists(filename) and os.path.getsize(filename) >= VIDEO_FILE_SIZE:
                    print("File size limit reached, creating new file")
                    video_writer.release()
                    video_writer = None
        
        # Display result with minimal processing
        cv2.imshow(window_name, result)
        
        # Check for key presses
        key = cv2.waitKey(1) & 0xFF
        if key == KEY_R and not recording:
            print("START RECORDING")
            recording = True
        elif key == KEY_S and recording:
            print("STOP RECORDING")
            recording = False
            if video_writer:
                video_writer.release()
                video_writer = None
        elif key == KEY_Q or key == KEY_ESC:
            print("EXIT")
            running = False
    
    # Clean up
    if video_writer:
        video_writer.release()
    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
