import numpy as np
import cv2
import time
import os
from threading import Thread
from queue import Queue
from collections import deque
from statistics import mean
def gstreamer_pipeline(
    sensor_id=0,
    capture_width=1920,
    capture_height=1080,
    display_width=1920,
    display_height=1080,
    framerate=60,
    flip_method=0,
):
    return (
        "nvarguscamerasrc sensor-id=%d ! "
        "video/x-raw(memory:NVMM), width=(int)%d, height=(int)%d, framerate=(fraction)%d/1 ! "
        "nvvidconv flip-method=%d ! "
        "video/x-raw, width=(int)%d, height=(int)%d, format=(string)BGRx ! "
        "videoconvert ! "
        "video/x-raw, format=(string)BGR ! appsink"
        """! queue max-size-buffers=3 leaky=downstream
        ! videoconvert
        ! video/x-raw, format=BGR"""
        % (
            sensor_id,
            capture_width,
            capture_height,
            framerate,
            flip_method,
            display_width,
            display_height,
        )
    )



class FPSCounter:
    def __init__(self, window_size=30):
        self.timestamps = deque(maxlen=window_size)
        
    def update(self):
        self.timestamps.append(time.time())
        
    def get_fps(self):
        if len(self.timestamps) < 2:
            return 0
        intervals = [t2 - t1 for t1, t2 in zip(self.timestamps, list(self.timestamps)[1:])]
        return 1 / mean(intervals) if intervals else 0

class VideoWriter:
    def __init__(self, filename, fourcc, fps, frameSize):
        self.writer = cv2.VideoWriter(filename, fourcc, fps, frameSize)
        self.queue = Queue(maxsize=300)  # Increased buffer size
        self.running = True
        self.thread = Thread(target=self._write_frames, daemon=True)
        self.thread.start()

    def write(self, frame):
        if not self.queue.full():
            self.queue.put(frame.copy())  # Make a copy to prevent memory issues
        else:
            print("Warning: Frame drop detected")

    def _write_frames(self):
        while self.running:
            if not self.queue.empty():
                frame = self.queue.get()
                self.writer.write(frame)
            else:
                time.sleep(0.001)  # Small sleep to prevent CPU thrashing

    def release(self):
        self.running = False
        self.thread.join()
        while not self.queue.empty():
            self.writer.write(self.queue.get())
        self.writer.release()

def main():
    # Constants
    KEY_R = ord('r')
    KEY_S = ord('s')
    KEY_Q = ord('q')
    KEY_ESC = 27
    VIDEO_FILE_SIZE = 100 * 1024 * 1024
    TARGET_FPS = 60
    
    # Initialize camera with optimized pipeline
    pipeline = gstreamer_pipeline()
    cap = cv2.VideoCapture(pipeline, cv2.CAP_GSTREAMER)
    
    # Optimize camera buffer settings
    cap.set(cv2.CAP_PROP_BUFFERSIZE, 3)
    
    # Get camera properties
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    
    fps_counter = FPSCounter()
    measured_fps = 0
    
    print(f'VCAP width : {width}')
    print(f'VCAP height: {height}')
    print('Measuring actual FPS...')
    
    # Pre-allocate arrays for better performance
    frame = np.empty((height, width, 3), dtype=np.uint8)
    frame_hsv = np.empty((height, width, 3), dtype=np.uint8)
    
    running = True
    recording = False
    video_writer = None
    window_name = time.strftime("%Y.%m.%d  %H.%M.%S", time.localtime())
    
    # Set high priority for the process (if running with sufficient privileges)
    try:
        os.nice(-20)
    except:
        print("Note: Could not set process priority")
    
    # Warmup camera
    print("Warming up camera...")
    for _ in range(30):
        cap.read()
    
    while running:
        ret = cap.grab()
        if not ret:
            continue
            
        ret, frame = cap.retrieve()
        if not ret:
            continue
        
        fps_counter.update()
        
        # Convert color space using pre-allocated array
        cv2.cvtColor(frame, cv2.COLOR_BGR2HSV, dst=frame_hsv)
        
        if recording:
            if video_writer is None:
                filename = time.strftime("%Y.%m.%d  %H.%M.%S", time.localtime()) + ".avi"
                fourcc = cv2.VideoWriter_fourcc(*'MP42')  # Switch to MJPG codec
                video_writer = VideoWriter(f'./VideoTesting/{filename}', fourcc, TARGET_FPS, (width, height))
                print(f"VIDEO WRITER INITIALIZED (Target FPS: {TARGET_FPS})")
            
            video_writer.write(frame_hsv)
            
            if cv2.getTickCount() % 30 == 0 and os.path.getsize(f'./VideoTesting/{filename}') >= VIDEO_FILE_SIZE:
                video_writer.release()
                video_writer = None
        
        # Display frame and FPS
        current_fps = fps_counter.get_fps()
        cv2.putText(frame_hsv, f"FPS: {current_fps:.1f}", (10, 30), 
                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
        cv2.imshow(window_name, frame_hsv)
        
        key = cv2.pollKey() & 0xFF
        if key == KEY_R and not recording:
            print("START RECORDING")
            recording = True
        elif key == KEY_S and recording:
            print("STOP RECORDING")
            recording = False
            if video_writer:
                video_writer.release()
                video_writer = None
        elif key == KEY_Q or key == KEY_ESC:
            print("EXIT")
            running = False
    
    if video_writer:
        video_writer.release()
    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
