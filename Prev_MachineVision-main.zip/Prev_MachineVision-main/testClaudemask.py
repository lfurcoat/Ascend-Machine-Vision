import numpy as np
import cv2
import time
import os
from threading import Thread
from queue import Queue
from collections import deque
from statistics import mean

def nothing(x):
    pass
    
def gstreamer_pipeline(
    sensor_id=0,
    capture_width=1280,
    capture_height=720,
    display_width=1280,
    display_height=720,
    framerate=60,
    flip_method=0,
):
    return (
        "nvarguscamerasrc sensor-id=%d ! "
        "video/x-raw(memory:NVMM), width=(int)%d, height=(int)%d, framerate=(fraction)%d/1 ! "
        "nvvidconv flip-method=%d ! "
        "video/x-raw, width=(int)%d, height=(int)%d, format=(string)BGRx ! "
        "videoconvert ! "
        "video/x-raw, format=(string)BGR ! appsink"
        """! queue max-size-buffers=3 leaky=downstream
        ! videoconvert
        ! video/x-raw, format=BGR"""
        % (
            sensor_id,
            capture_width,
            capture_height,
            framerate,
            flip_method,
            display_width,
            display_height,
        )
    )



class FPSCounter:
    def __init__(self, window_size=30):
        self.timestamps = deque(maxlen=window_size)
        
    def update(self):
        self.timestamps.append(time.time())
        
    def get_fps(self):
        if len(self.timestamps) < 2:
            return 0
        intervals = [t2 - t1 for t1, t2 in zip(self.timestamps, list(self.timestamps)[1:])]
        return 1 / mean(intervals) if intervals else 0

class VideoWriter:
    def __init__(self, filename, fourcc, fps, frameSize):
        self.writer = cv2.VideoWriter(filename, fourcc, fps, frameSize)
        self.queue = Queue(maxsize=300)  # Increased buffer size
        self.running = True
        self.thread = Thread(target=self._write_frames, daemon=True)
        self.thread.start()

    def write(self, frame):
        if not self.queue.full():
            self.queue.put(frame.copy())  # Make a copy to prevent memory issues
        else:
            print("Warning: Frame drop detected")

    def _write_frames(self):
        while self.running:
            if not self.queue.empty():
                frame = self.queue.get()
                self.writer.write(frame)
            else:
                time.sleep(0.001)  # Small sleep to prevent CPU thrashing

    def release(self):
        self.running = False
        self.thread.join()
        while not self.queue.empty():
            self.writer.write(self.queue.get())
        self.writer.release()

def main():

    # Constants
    KEY_R = ord('r')
    KEY_S = ord('s')
    KEY_Q = ord('q')
    KEY_ESC = 27
    VIDEO_FILE_SIZE = 100 * 1024 * 1024
    TARGET_FPS = 60
    
    # Initialize camera with optimized pipeline
    pipeline = gstreamer_pipeline()
    cap = cv2.VideoCapture(pipeline, cv2.CAP_GSTREAMER)
    
    # Optimize camera buffer settings
    cap.set(cv2.CAP_PROP_BUFFERSIZE, 3)
    
    # Get camera properties
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    
    fps_counter = FPSCounter()
    measured_fps = 0
    
    print(f'VCAP width : {width}')
    print(f'VCAP height: {height}')
    print('Measuring actual FPS...')
    
    # Pre-allocate arrays for better performance
    frame = np.empty((height, width, 3), dtype=np.uint8)
    frame_hsv = np.empty((height, width, 3), dtype=np.uint8)
    
    running = True
    recording = False
    video_writer = None
    window_name = time.strftime("%Y.%m.%d  %H.%M.%S", time.localtime())
    
    # Set high priority for the process (if running with sufficient privileges)
    try:
        os.nice(-20)
    except:
        print("Note: Could not set process priority")
    
    # Warmup camera
    print("Warming up camera...")
    for _ in range(30):
        cap.read()

    while running:
        ret = cap.grab()
        if not ret:
            continue
            
        ret, frame = cap.retrieve()
        if not ret:
            continue
        
        fps_counter.update()
        
        # Convert color space using pre-allocated array
        gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        # Trackbars
        l_h = cv2.getTrackbarPos("L-H","Trackbars")
        l_s = cv2.getTrackbarPos("L-S","Trackbars")
        l_v = cv2.getTrackbarPos("L-V","Trackbars")
        u_h = cv2.getTrackbarPos("U-H","Trackbars")
        u_s = cv2.getTrackbarPos("U-S","Trackbars")
        u_v = cv2.getTrackbarPos("U-V","Trackbars")
        
        lower = np.array([l_h,l_s,l_v])
        upper = np.array([u_h,u_s,u_v])
        # Masking
        mask = cv2.inRange(gray_frame,lower,upper)
        mask_inv = cv2.bitwise_not(mask)
        mask1 = cv2.inRange(gray_frame, (30,66,0), (119,245,218)) # blue hue
        mask1_inv = cv2.bitwise_not(mask1)
        mask2 = cv2.inRange(gray_frame, (113,79,0), (198,215,186))
        mask2_inv = cv2.bitwise_not(mask2)
        mask_combined = mask1 + mask2
        
        result = cv2.bitwise_and(frame, frame, mask=mask_combined)
        
        # CONTOURING
        contours, _ = cv2.findContours(mask_combined, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
        #largest_contour = sorted(contours, key=cv2.contourArea, reverse=True)[0]
        
        
        for contour in contours:
        	# You can adjust the color and thickness to your liking
        	cv2.drawContours(frame, [contour], -1, (0, 0, 255), 2)  # Red color, thickness of 2
        # CONTOURING
        #contours, hierarchy = cv2.findContours(mask2, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        #for contour in contours:
        	# You can adjust the color and thickness to your liking
        	#cv2.drawContours(frame, [contour], -1, (0, 255, 0), 2)  # Red color, thickness of 2

        
        
        
        #ret, thresh = cv2.imread(frame)
        #contours, hierarchy = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
        #cv2.drawContours(frame, contours, -1, (0, 0, 255), 2)
        # Display crosshairs
        height, width, _ = result.shape
        

        center_x = width // 2
        center_y = height //2
        
        line_length = 25
        
        
        if recording:
            if video_writer is None:
                filename = time.strftime("%Y.%m.%d  %H.%M.%S", time.localtime()) + ".avi"
                fourcc = cv2.VideoWriter_fourcc(*'MP42')  # Switch to MJPG codec
                video_writer = VideoWriter(f'./VideoTesting/{filename}', fourcc, TARGET_FPS, (width, height))
                print(f"VIDEO WRITER INITIALIZED (Target FPS: {TARGET_FPS})")
            
            cv2.line(result, (center_x - line_length, center_y), (center_x + line_length, center_y), (255, 255, 255), 1)
            cv2.line(result, (center_x, center_y - line_length), (center_x, center_y + line_length), (255, 225, 255), 1)
            
            video_writer.write(frame)
            
            if cv2.getTickCount() % 30 == 0 and os.path.getsize(f'./VideoTesting/{filename}') >= VIDEO_FILE_SIZE:
                video_writer.release()
                video_writer = None
        
        # Display frame and FPS
        current_fps = fps_counter.get_fps()
        cv2.putText(frame, f"FPS: {current_fps:.1f}", (10, 30), 
                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
        
        
  
        cv2.line(frame, (center_x - line_length, center_y), (center_x + line_length, center_y), (255, 255, 255), 1)
        cv2.line(frame, (center_x, center_y - line_length), (center_x, center_y + line_length), (255, 225, 255), 1)
        cv2.imshow(window_name, frame)
        key = cv2.pollKey() & 0xFF
        if key == KEY_R and not recording:
            print("START RECORDING")
            recording = True
        elif key == KEY_S and recording:
            print("STOP RECORDING")
            recording = False
            if video_writer:
                video_writer.release()
                video_writer = None
        elif key == KEY_Q or key == KEY_ESC:
            print("EXIT")
            running = False
    
    if video_writer:
        video_writer.release()
    	#cap.release()
    	#cv2.destroyAllWindows()

if __name__ == "__main__":
    cv2.namedWindow("Trackbars")

    cv2.createTrackbar("L-H","Trackbars",0,255,nothing)
    cv2.createTrackbar("L-S","Trackbars",0,255,nothing)
    cv2.createTrackbar("L-V","Trackbars",0,255,nothing)
    cv2.createTrackbar("U-H","Trackbars",0,255,nothing)
    cv2.createTrackbar("U-S","Trackbars",0,255,nothing)
    cv2.createTrackbar("U-V","Trackbars",0,255,nothing)

    main()
