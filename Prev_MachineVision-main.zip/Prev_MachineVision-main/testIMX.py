import numpy as np
import cv2
import time
import os
from collections import deque
from statistics import mean
def gstreamer_pipeline(
    sensor_id=0,
    capture_width=640,
    capture_height=480,
    display_width=1280,
    display_height=720,
    framerate=120,
    flip_method=0,
):
    return (
        "nvarguscamerasrc sensor-id=%d ! "
        "video/x-raw(memory:NVMM), width=(int)%d, height=(int)%d, framerate=(fraction)%d/1 ! "
        "nvvidconv flip-method=%d ! "
        "video/x-raw, width=(int)%d, height=(int)%d, format=(string)BGRx ! "
        "videoconvert ! "
        "video/x-raw, format=(string)BGR ! appsink"
        """! queue max-size-buffers=3 leaky=downstream
        ! videoconvert
        ! video/x-raw, format=BGR"""
        % (
            sensor_id,
            capture_width,
            capture_height,
            framerate,
            flip_method,
            display_width,
            display_height,
        )
    )
class FPSCounter:
    def __init__(self, window_size=30):
        self.timestamps = deque(maxlen=window_size)
        
    def update(self):
        self.timestamps.append(time.time())
        
    def get_fps(self):
        if len(self.timestamps) < 2:
            return 0
        intervals = [t2 - t1 for t1, t2 in zip(self.timestamps, list(self.timestamps)[1:])]
        return 1 / mean(intervals) if intervals else 0


if __name__ == "__main__":
	# keys
	KEY_R = ord('r') # record
	KEY_S = ord('s') # quit recording
	KEY_Q = ord('q') # quit
	KEY_ESC = 27
	
	VIDEO_FILE_SIZE = 100*1024*1024 # 10 MB files

	# states
	running = True
	recording = False
	create_new_file = True
	fps_counter = FPSCounter()
	measured_fps = 0
	# window name
	window_name = time.strftime("%Y.%m.%d  %H.%M.%S", time.localtime())
	
	cap = cv2.VideoCapture(gstreamer_pipeline(flip_method=0), cv2.CAP_GSTREAMER)
	fps = float(cap.get(cv2.CAP_PROP_FPS)) # get fps
	width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
	height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
	# Pre-allocate arrays for better performance
	frame = np.empty((height, width, 3), dtype=np.uint8)
	#frame_hsv = np.empty((height, width, 3), dtype=np.uint8)
	print('VCAP width :', width)
	print('VCAP height:', height)
	print('VCAP fps   :', fps)
	
	while(running):
    		# Capture frame-by-frame
    		ret, frame = cap.read()
    		frame = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    		if recording:
    			if create_new_file:
    				filename = time.strftime("%Y.%m.%d  %H.%M.%S", time.localtime()) + ".mp4"
    				
    				fourcc = cv2.VideoWriter_fourcc(*'AVC1') # .avi
    				
    				fout = cv2.VideoWriter(filename, fourcc, 120, (width, height))
    				create_new_file = False
    				# check video writer initialization
    				if not fout.isOpened():
    					print("ERROR: VIDEO WRITER NOT INITIALIZED")
    					break
    				else:
    					print("VIDEO WRITER INITIALIZED")
    			# write frame to file
    			if fout.isOpened():
    				fout.write(frame)
    			
    			# check file size
    			if os.path.getsize(filename) >= VIDEO_FILE_SIZE:
    				fout.release() # close current file
    				create_new_file = True # create new file in next loop
    			
    			

    		# Our operations on the frame come here
    		fps_counter.update()
    		current_fps = fps_counter.get_fps()
    		cv2.putText(frame, f"FPS: {current_fps:.1f}", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
    		# Display the resulting frame
    		cv2.imshow(window_name,frame)
    		
    		key = cv2.pollKey() & 0xFF
    		if key == KEY_R and not recording:
    			print("START RECORDING")
    			recording = True
    			create_new_file = True
    		elif key == KEY_S and recording:
    			print("STOP RECORDING")
    			recording = False
    			create_new_file = False
    			fout.release()
    		elif key == KEY_Q or key == KEY_ESC:
    			print("EXIT")
    			running = False
    		#if cv2.waitKey(1) & 0xFF == ord('q'):
        		#break

		# When everything done, release the capture
		
	cap.release()
	cv2.destroyAllWindows()

    
    
